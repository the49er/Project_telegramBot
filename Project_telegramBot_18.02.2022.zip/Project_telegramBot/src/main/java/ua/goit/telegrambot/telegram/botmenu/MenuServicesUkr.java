package ua.goit.telegrambot.telegram.botmenu;

import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.InlineKeyboardButton;

import java.util.ArrayList;
import java.util.List;

public class MenuServicesUkr extends BotServMenu{
    @Override
    public InlineKeyboardMarkup getInfoSetMenu() {
        InlineKeyboardButton getInfo = InlineKeyboardButton
                .builder()
                .text("Отримати інформацію ℹ️")
                .callbackData("getInfoUkr")
                .build();

        InlineKeyboardButton settings = InlineKeyboardButton
                .builder()
                .text("Налаштування \uD83D\uDD27")
                .callbackData("settingUkr")
                .build();

        List<InlineKeyboardButton> keyboardButtonsRow1 = new ArrayList<>();
        keyboardButtonsRow1.add(getInfo);

        List<InlineKeyboardButton> keyboardButtonsRow2 = new ArrayList<>();
        keyboardButtonsRow2.add(settings);

        List<List<InlineKeyboardButton>> keyboard = new ArrayList<>();
        keyboard.add(keyboardButtonsRow1);
        keyboard.add(keyboardButtonsRow2);

        InlineKeyboardMarkup markup = new InlineKeyboardMarkup();
        markup.setKeyboard(keyboard);
        return markup;
    }

    @Override
    public InlineKeyboardMarkup getSettingsMenu() {
        return null;
    }

    @Override
    public InlineKeyboardMarkup getCurrencyMenu() {
        return null;
    }
}
