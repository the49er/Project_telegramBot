package ua.goit.telegrambot.telegram;

import lombok.extern.slf4j.Slf4j;
import org.telegram.telegrambots.extensions.bots.commandbot.TelegramLongPollingCommandBot;
import org.telegram.telegrambots.meta.api.methods.send.SendMessage;
import org.telegram.telegrambots.meta.api.objects.CallbackQuery;
import org.telegram.telegrambots.meta.api.objects.Message;
import org.telegram.telegrambots.meta.api.objects.Update;
import org.telegram.telegrambots.meta.api.objects.User;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.InlineKeyboardButton;
import org.telegram.telegrambots.meta.exceptions.TelegramApiException;
import ua.goit.telegrambot.telegram.botmenu.MenuServicesEng;

import ua.goit.telegrambot.telegram.botmenu.MenuServicesUkr;
import ua.goit.telegrambot.telegram.command.eng.mainmenu.GetInfoCommand;
import ua.goit.telegrambot.telegram.command.eng.mainmenu.SettingsCommand;
import ua.goit.telegrambot.telegram.botmenu.StartBotCommand;
import ua.goit.telegrambot.telegram.command.eng.StartEngCommand;
import ua.goit.telegrambot.telegram.command.eng.mainmenu.settings.ChooseABank;
import ua.goit.telegrambot.telegram.command.eng.mainmenu.settings.ChooseСurrencies;
import ua.goit.telegrambot.telegram.command.eng.mainmenu.settings.NotificationsTime;
import ua.goit.telegrambot.telegram.command.eng.mainmenu.settings.NumberOfChars;
import ua.goit.telegrambot.telegram.command.ukr.StartUkrCommand;

import java.util.ArrayList;
import java.util.List;

@Slf4j
public class TelegramCurrencyBot extends TelegramLongPollingCommandBot {

    public TelegramCurrencyBot() {
        register(new StartBotCommand());
        log.info("register command StartBotCommand");
        //language menu
        register(new StartEngCommand());
        log.info("register command StartEngCommand");
        register(new StartUkrCommand());
        log.info("register command StartUkrCommand");

        //eng main menu
        register(new SettingsCommand());
        log.info("register command SettingsCommand");

        register(new GetInfoCommand());

        //eng settings menu
        register(new NotificationsTime());
        register(new ChooseABank());
        register(new NumberOfChars());
        register(new ChooseСurrencies());
    }

    @Override
    public String getBotUsername() {
        return BotConstants.BOT_NAME;
    }

    @Override
    public String getBotToken() {
        return BotConstants.BOT_TOKEN;
    }

    @Override
    public void processNonCommandUpdate(Update update) {
        log.info("update has message");
        MenuServicesEng menuServicesEng = new MenuServicesEng();
        MenuServicesUkr menuServicesUkr = new MenuServicesUkr();
        SendMessage sendMessage = new SendMessage();

        if (update.hasCallbackQuery()) {
            log.info("message is callBackQuery");
            String data = update.getCallbackQuery().getData();
            long chat_id = update.getCallbackQuery().getMessage().getChatId();;
            switch (data) {
                case "eng":
                   log.info("message with callBackData 'eng' ");
                    sendMessage.setReplyMarkup(menuServicesEng.getInfoSetMenu());
                    sendMessage.setText(menuServicesEng.getMessageInfoSetMenu());
                    sendMessage.setChatId(Long.toString(chat_id));
                    break;

                case "ukr":
                    log.info("message with callBackData 'ukr' ");
                    sendMessage.setReplyMarkup(menuServicesUkr.getInfoSetMenu());
                    sendMessage.setText(menuServicesUkr.getMessageInfoSetMenu());
                    sendMessage.setChatId(Long.toString(chat_id));

                case "getInfoEng":
                    sendMessage.setReplyMarkup(menuServicesEng.getCurrencyMenu());
                    sendMessage.setText(menuServicesEng.getMessageCurrencyMenu());
                    sendMessage.setChatId(Long.toString(chat_id));
                    break;

                case "getInfoUkr":
                    sendMessage.setReplyMarkup(menuServicesUkr.getCurrencyMenu());
                    sendMessage.setText(menuServicesUkr.getMessageCurrencyMenu());
                    sendMessage.setChatId(Long.toString(chat_id));
                    break;

                case "settingEng":
                    sendMessage.setReplyMarkup(menuServicesEng.getSettingsMenu());
                    sendMessage.setText(menuServicesEng.getMessageSettingsMenu());
                    sendMessage.setChatId(Long.toString(chat_id));
                    break;

                case "settingUkr":
                    sendMessage.setReplyMarkup(menuServicesUkr.getSettingsMenu());
                    sendMessage.setText(menuServicesUkr.getMessageSettingsMenu());
                    sendMessage.setChatId(Long.toString(chat_id));
                    break;

                default:
                    sendMessage.setText("Error CallBackQuery");
                    sendMessage.setChatId(Long.toString(chat_id));
                    break;
            }
            try {
                execute(sendMessage);
            } catch (TelegramApiException e) {
                e.printStackTrace();
            }
        }


        if (update.hasMessage() && update.getMessage().hasText()) {
        long chat_id = update.getMessage().getChatId();
            String messageReceived = update.getMessage().getText();

            switch (messageReceived) {
                case "start":
                    sendMessage.setReplyMarkup(menuServicesUkr.getInfoSetMenu());
                    sendMessage.setText("BTC");
                    sendMessage.setChatId(Long.toString(chat_id));
                    break;

                case "USD":
                    sendMessage.setReplyMarkup(menuServicesEng.getInfoSetMenu());
                    sendMessage.setText("USD");
                    sendMessage.setChatId(Long.toString(chat_id));
                    break;
                default:
                    sendMessage.setText("Error");
                    sendMessage.setChatId(Long.toString(chat_id));
                    break;
            }
            try {
                execute(sendMessage);
            } catch (TelegramApiException e) {
                e.printStackTrace();
            }
        }
    }


    @Override
    public void onUpdatesReceived(List<Update> updates) {
        super.onUpdatesReceived(updates);
    }
}
