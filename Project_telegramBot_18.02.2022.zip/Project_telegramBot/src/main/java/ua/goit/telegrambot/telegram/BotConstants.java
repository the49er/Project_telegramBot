package ua.goit.telegrambot.telegram;

import org.telegram.telegrambots.meta.api.methods.send.SendMessage;

public class BotConstants {

    public static final SendMessage SEND_MESSAGE = new SendMessage();

    //public static final String BOT_NAME = "currencyCheckerNewBot";
    public static final String BOT_NAME = "fresh_currency_exchange_bot";
    //public static final String BOT_TOKEN = "5106700465:AAGKyVPVsM06SPfllAporcZy_4qF8Q0Jvf0";
    public static final String BOT_TOKEN = "1985070793:AAGh1ZY3ZWdJ3ejQ5G69Az8LVE4-5ARp7ko";



}
