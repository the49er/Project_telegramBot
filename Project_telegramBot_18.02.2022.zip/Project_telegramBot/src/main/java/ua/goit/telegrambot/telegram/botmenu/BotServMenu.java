package ua.goit.telegrambot.telegram.botmenu;

import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardMarkup;

public abstract class BotServMenu {

    //GetInfo and Settings Menu
    public abstract InlineKeyboardMarkup getInfoSetMenu();

    //GetInfo and Settings Menu MESSAGE
    public String getMessageInfoSetMenu (){
        return "Main message of Lang Menu";
    }

    //Settings menu
    public abstract InlineKeyboardMarkup getSettingsMenu ();

    //Settings Menu MESSAGE
    public String getMessageSettingsMenu () {
        return "Main message of settings Menu";
    }

    //Currency menu
    public abstract InlineKeyboardMarkup getCurrencyMenu();

    //Currency menu MESSAGE
    public String getMessageCurrencyMenu(){
        return "Message currency Menu";
    }



}
