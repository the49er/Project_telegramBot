package ua.goit.telegrambot.ui;

public class CharactersAfterComma {

}
