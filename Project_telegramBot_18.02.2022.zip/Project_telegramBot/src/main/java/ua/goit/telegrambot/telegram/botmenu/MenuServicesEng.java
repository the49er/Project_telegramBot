package ua.goit.telegrambot.telegram.botmenu;

import org.telegram.telegrambots.meta.api.objects.replykeyboard.InlineKeyboardMarkup;
import org.telegram.telegrambots.meta.api.objects.replykeyboard.buttons.InlineKeyboardButton;

import java.util.ArrayList;
import java.util.List;

public class MenuServicesEng extends BotServMenu{

    @Override
    public InlineKeyboardMarkup getInfoSetMenu() {
        InlineKeyboardButton getInfo = InlineKeyboardButton
                .builder()
                .text("Get info ℹ️")
                .callbackData("getInfoEng")
                .build();

        InlineKeyboardButton settings = InlineKeyboardButton
                .builder()
                .text("Settings \uD83D\uDD27")
                .callbackData("settingEng")
                .build();

        List<InlineKeyboardButton> keyboardButtonsRow1 = new ArrayList<>();
        keyboardButtonsRow1.add(getInfo);

        List<InlineKeyboardButton> keyboardButtonsRow2 = new ArrayList<>();
        keyboardButtonsRow2.add(settings);

        List<List<InlineKeyboardButton>> keyboard = new ArrayList<>();
        keyboard.add(keyboardButtonsRow1);
        keyboard.add(keyboardButtonsRow2);

        InlineKeyboardMarkup markup = new InlineKeyboardMarkup();
        markup.setKeyboard(keyboard);
        return markup;
    }

    @Override
    public String getMessageInfoSetMenu() {
        return "Choose your next step";
    }

    @Override
    public InlineKeyboardMarkup getSettingsMenu() {
        InlineKeyboardButton bank = InlineKeyboardButton
                .builder()
                .text("Bank")
                .callbackData("chooseApi")
                .build();

        InlineKeyboardButton currencies = InlineKeyboardButton
                .builder()
                .text("Currencies")
                .callbackData("currency")
                .build();

        InlineKeyboardButton notificationTime = InlineKeyboardButton
                .builder()
                .text("Notification")
                .callbackData("notificationTime")
                .build();

        InlineKeyboardButton numberOfSymb = InlineKeyboardButton
                .builder()
                .text("Rounding")
                .callbackData("Number of symbols after comma")
                .build();


        List<InlineKeyboardButton> keyboardButtonsRow1 = new ArrayList<>();
        keyboardButtonsRow1.add(bank);

        List<InlineKeyboardButton> keyboardButtonsRow2 = new ArrayList<>();
        keyboardButtonsRow2.add(currencies);

        List<InlineKeyboardButton> keyboardButtonsRow3 = new ArrayList<>();
        keyboardButtonsRow3.add(notificationTime);

        List<InlineKeyboardButton> keyboardButtonsRow4 = new ArrayList<>();
        keyboardButtonsRow4.add(numberOfSymb);

        List<List<InlineKeyboardButton>> settingsKeyboard = new ArrayList<>();
        settingsKeyboard.add(keyboardButtonsRow1);
        settingsKeyboard.add(keyboardButtonsRow2);
        settingsKeyboard.add(keyboardButtonsRow3);
        settingsKeyboard.add(keyboardButtonsRow4);

        InlineKeyboardMarkup markup = new InlineKeyboardMarkup();
        markup.setKeyboard(settingsKeyboard);
        return markup;
    }

    @Override
    public String getMessageSettingsMenu() {
        return "Please select a setting";
    }

    @Override
    public InlineKeyboardMarkup getCurrencyMenu () {
        InlineKeyboardButton usd = InlineKeyboardButton
                .builder()
                .text("USD")
                .callbackData("usd")
                .build();

        InlineKeyboardButton eur = InlineKeyboardButton
                .builder()
                .text("EUR")
                .callbackData("eur")
                .build();

        InlineKeyboardButton gbp = InlineKeyboardButton
                .builder()
                .text("GBP")
                .callbackData("gbp")
                .build();

        List<InlineKeyboardButton> keyboardButtonsRow1 = new ArrayList<>();
        keyboardButtonsRow1.add(usd);

        List<InlineKeyboardButton> keyboardButtonsRow2 = new ArrayList<>();
        keyboardButtonsRow2.add(eur);

        List<InlineKeyboardButton> keyboardButtonsRow3 = new ArrayList<>();
        keyboardButtonsRow3.add(gbp);

        List<List<InlineKeyboardButton>> currencyKeyboard = new ArrayList<>();
        currencyKeyboard.add(keyboardButtonsRow1);
        currencyKeyboard.add(keyboardButtonsRow2);
        currencyKeyboard.add(keyboardButtonsRow3);

        InlineKeyboardMarkup markup = new InlineKeyboardMarkup();
        markup.setKeyboard(currencyKeyboard);
        return markup;
    }
    @Override
    public String getMessageCurrencyMenu(){
        return "Choose currency";
    }
}
